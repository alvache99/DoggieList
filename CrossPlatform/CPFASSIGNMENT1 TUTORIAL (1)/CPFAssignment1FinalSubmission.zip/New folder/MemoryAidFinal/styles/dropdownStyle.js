import {StyleSheet} from 'react-native';


export const dropdownStyle = StyleSheet.create({
  inputIOS: {
    borderRadius:12,backgroundColor:'#A9A9A9',width:200,height:40,fontSize:25,textAlign:'center'
  },
  inputAndroid: {
    borderRadius:12,backgroundColor:'#A9A9A9',width:200,height:40,fontSize:25,textAlign:'center'
  },
})