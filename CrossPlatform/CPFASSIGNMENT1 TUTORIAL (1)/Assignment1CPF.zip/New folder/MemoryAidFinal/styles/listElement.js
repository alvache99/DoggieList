import {StyleSheet} from 'react-native';

export const listElement = StyleSheet.create({
    element:{
        padding:30
    }


})